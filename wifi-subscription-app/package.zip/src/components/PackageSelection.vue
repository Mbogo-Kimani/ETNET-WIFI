<template>
  <div class="package-selection">
    <div v-for="(pkg, index) in packages" :key="index" class="package">
      <p class="time">{{ formatDuration(pkg.duration) }}</p>
      <p class="ksh"><span>Ksh</span> {{ pkg.cost }}</p>
     
      <button @click="goToCheckout(pkg.duration, pkg.cost)">Get Access</button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      packages: [],
    };
  },
  mounted() {
    this.fetchPackages();
  },
  methods: {
    fetchPackages() {
      fetch("http://localhost:3000/api/street_packages")
        .then((response) => {
          if (!response.ok) throw new Error("Failed to fetch packages");
          return response.json();
        })
        .then((data) => {
          console.log("Data received:", data);
          this.packages = data.packages || []; // Use the correct field from API
        })
        .catch((error) => console.error("Error fetching packages:", error));
    },
    formatDuration(seconds) {
      const days = Math.floor(seconds / 86400);
      const hours = Math.floor((seconds % 86400) / 3600);
      if (days > 0) return `${days} Day${days > 1 ? 's' : ''}`;
      if (hours > 0) return `${hours} Hour${hours > 1 ? 's' : ''}`;
      return `${seconds} Seconds`;
    },
    goToCheckout(duration, price) {
      console.log("Navigating to checkout with:", { duration, price });
      this.$router.push({
        name: "checkout",
        query: { duration, price }, // Use query parameters
      });
    },
  },
};
</script>


<style scoped>
.package-selection {
  background: whitesmoke;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  margin-top: -90px;
  padding-top: 30px;
  padding-bottom: 30px;
  border-radius: 24px;
  width: auto;
}

.package {
  border-radius: 12px;
  background: #fff;
  padding: 1px;
  margin: 10px;
  width: 100%;
  max-width: 300px;
  text-align: center;
  box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.time {
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
    Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
  font-size: 30px;
  font-weight: bold;
  color: #202b61;
  margin-bottom: -45px;
}

.ksh {
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
    Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
  color: #704fde;
  font-size: 50px;
  font-weight: 900;
  margin-bottom: -0.1px;
}

.desc{
  font-size: 20px;
  font-weight: 700;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI",
  Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue",
}

span {
  font-size: 20px;
  font-weight: 900;
}

button {
  background: #f99526;
  color: #fff;
  font-weight: 900;
  font-size: 20px;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
    Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
  padding: 8px;
  border-radius: 12px;
  width: 70%;
  margin-bottom: 15px;
  outline-style: none;
  border-style: none;
  transition: 0.3s ease;
}

button:hover {
  background-color: #eb7e03;
  cursor: pointer;
}
</style>
